/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@devolution.com
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_RLEaccel.c,v 1.3.2.12 2000/07/17 02:39:35 hercules Exp $";
#endif

/* The RLE encoding implementation for software colorkey acceleration */
/*
 * This is Yorick's frobbling and rewrite of Xark's rewrite of Sam's original
 * RLE code. Many thanks to Xark for benchmarks and comments leading to
 * this code.
 */

/*
 * The encoding translates the image data to a stream of segments of the form
 *
 * <skip> <run> <data>
 *
 * where <skip> is the number of transparent pixels to skip,
 *       <run>  is the number of opaque pixels to blit,
 * and   <data> are the pixels themselves.
 * <skip> and <run> are unsigned 8 bit integers, except for 32 bit depth where
 * they are 16 bit. This makes the pixel data aligned at all times.
 * Segments never wrap around from one scan line to the next.
 *
 * The end of the sequence is marked by a zero <skip>,<run> pair at the
 * beginning of a line.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "SDL_types.h"
#include "SDL_video.h"
#include "SDL_error.h"
#include "SDL_sysvideo.h"
#include "SDL_blit.h"
#include "SDL_memops.h"
#include "SDL_RLEaccel_c.h"

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

/*
 * This takes care of the case when the surface is clipped on the left and/or
 * right. Top clipping has already been taken care of.
 */
static void SDL_RLEClipBlit(int w, Uint8 *srcbuf, SDL_Surface *dst,
			    Uint8 *dstbuf, SDL_Rect *srcrect)
{
#define RLECLIPBLIT(bpp, Type)						      \
    do {								      \
	int linecount = srcrect->h;					      \
	int ofs = 0;							      \
	int left = srcrect->x;						      \
	int right = left + srcrect->w;					      \
	dstbuf -= left * bpp;						      \
	for(;;) {							      \
	    int run;							      \
	    ofs += *(Type *)srcbuf;					      \
	    run = ((Type *)srcbuf)[1];					      \
	    srcbuf += 2 * sizeof(Type);					      \
	    if(run) {							      \
		/* clip to left and right borders */			      \
		if(ofs < right) {					      \
		    int start = 0;					      \
		    int len = run;					      \
		    int startcol;					      \
		    if(left - ofs > 0) {				      \
			start = left - ofs;				      \
			len -= start;					      \
			if(len < 0)					      \
			    goto nocopy ## bpp;				      \
		    }							      \
		    startcol = ofs + start;				      \
		    if(len > right - startcol)				      \
			len = right - startcol;				      \
		    SDL_memcpy(dstbuf + startcol * bpp, srcbuf + start * bpp, \
			       (unsigned)(len * bpp));			      \
		}							      \
	    nocopy ## bpp:						      \
		srcbuf += run * bpp;					      \
		ofs += run;						      \
	    } else if(!ofs)						      \
		break;							      \
	    if(ofs == w) {						      \
		ofs = 0;						      \
		dstbuf += dst->pitch;					      \
		if(!--linecount)					      \
		    break;						      \
	    }								      \
	}								      \
    } while(0)

    switch(dst->format->BytesPerPixel) {
    case 1: RLECLIPBLIT(1, Uint8); break;
    case 2: RLECLIPBLIT(2, Uint8); break;
    case 3: RLECLIPBLIT(3, Uint8); break;
    case 4: RLECLIPBLIT(4, Uint16); break;
    }

#undef RLECLIPBLIT

}

/* Function to quickly blit a RLE buffer */
int SDL_RLEBlit(SDL_Surface *src, SDL_Rect *srcrect,
			SDL_Surface *dst, SDL_Rect *dstrect)
{
	Uint8 *dstbuf;
	Uint8 *srcbuf;
	int x, y;
	int w = src->w;

	/* Lock the destination if necessary */
	if ( dst->flags & (SDL_HWSURFACE|SDL_ASYNCBLIT) ) {
		SDL_VideoDevice *video = current_video;
		SDL_VideoDevice *this  = current_video;
		if ( video->LockHWSurface(this, dst) < 0 ) {
			return(-1);
		}
	}

	/* Set up the source and destination pointers */
	x = dstrect->x;
	y = dstrect->y;
	dstbuf = (Uint8 *)dst->pixels + dst->offset
	         + y * dst->pitch + x * src->format->BytesPerPixel;
	srcbuf = (Uint8 *)src->map->sw_data->aux_data;

	{
	    /* skip lines at the top if neccessary */
	    int vskip = srcrect->y;
	    int ofs = 0;
	    if(vskip) {

#define RLESKIP(bpp, Type)			\
		for(;;) {			\
		    int run;			\
		    ofs += *(Type *)srcbuf;	\
		    run = ((Type *)srcbuf)[1];	\
		    srcbuf += sizeof(Type) * 2;	\
		    if(run) {			\
			srcbuf += run * bpp;	\
			ofs += run;		\
		    } else if(!ofs)		\
			goto done;		\
		    if(ofs == w) {		\
			ofs = 0;		\
			if(!--vskip)		\
			    break;		\
		    }				\
		}

		switch(src->format->BytesPerPixel) {
		case 1: RLESKIP(1, Uint8); break;
		case 2: RLESKIP(2, Uint8); break;
		case 3: RLESKIP(3, Uint8); break;
		case 4: RLESKIP(4, Uint16); break;
		}

#undef RLESKIP

	    }
	}

	/* if left or right edge clipping needed, call clip blit */
	if ( srcrect->x || srcrect->w != src->w ) {
	    SDL_RLEClipBlit(w, srcbuf, dst, dstbuf, srcrect);
	} else {

#define RLEBLIT(bpp, Type)						\
	do {								\
	    int linecount = srcrect->h;					\
	    int ofs = 0;						\
	    for(;;) {							\
		unsigned run;						\
		ofs += *(Type *)srcbuf;					\
		run = ((Type *)srcbuf)[1];				\
		srcbuf += 2 * sizeof(Type);				\
		if(run) {						\
		    SDL_memcpy(dstbuf + ofs * bpp, srcbuf, run * bpp);	\
		    srcbuf += run * bpp;				\
		    ofs += run;						\
		} else if(!ofs)						\
		    break;						\
		if(ofs == w) {						\
		    ofs = 0;						\
		    dstbuf += dst->pitch;				\
		    if(!--linecount)					\
			break;						\
		}							\
	    }								\
	} while(0)

	      switch(src->format->BytesPerPixel) {
	      case 1: RLEBLIT(1, Uint8); break;
	      case 2: RLEBLIT(2, Uint8); break;
	      case 3: RLEBLIT(3, Uint8); break;
	      case 4: RLEBLIT(4, Uint16); break;
	      }

	}

done:
	/* Unlock the destination if necessary */
	if ( dst->flags & (SDL_HWSURFACE|SDL_ASYNCBLIT) ) {
		SDL_VideoDevice *video = current_video;
		SDL_VideoDevice *this  = current_video;
		video->UnlockHWSurface(this, dst);
	}
	return(0);
}

static int Transparent(Uint8 *srcbuf, SDL_PixelFormat *fmt)
{
	switch (fmt->BytesPerPixel) {
		case 1:
			return( *srcbuf == (Uint8)fmt->colorkey);
		case 2:
			return(*((Uint16 *)srcbuf) == (Uint16)fmt->colorkey);
		case 3: {
			Uint32 pixel;

			if(SDL_BYTEORDER == SDL_LIL_ENDIAN)
			        pixel = srcbuf[0] + (srcbuf[1] << 8)
				        + (srcbuf[2] << 16);
			else
			        pixel = (srcbuf[0] << 16) + (srcbuf[1] << 8)
				        + srcbuf[2];
			return(pixel == fmt->colorkey);
		}
		case 4:
			return(*((Uint32 *)srcbuf) == fmt->colorkey);
	        default:
		        return 0;	/* avoid gcc warning */
	}
}

int SDL_RLESurface(SDL_Surface *surface)
{
        Uint8 *rlebuf, *dst;
	int maxn;
	int x, y, trim;
	Uint8 *srcbuf, *curbuf;
	int maxsize;
	int skip, run, blanks, blankline;
	int bpp = surface->format->BytesPerPixel;

	/* Clear any previous RLE conversion */
	if ( (surface->flags & SDL_RLEACCEL) == SDL_RLEACCEL ) {
		SDL_UnRLESurface(surface, 1);
	}

	/* We don't support alpha blending on RLE surfaces */
	if ( (surface->flags & SDL_SRCALPHA) == SDL_SRCALPHA ) {
		return(-1);
	}

	/* We also don't support RLE encoding of bitmaps */
	if ( surface->format->BitsPerPixel < 8 ) {
		return(-1);
	}

	/* Lock the surface if it's in hardware */
	if ( surface->flags & (SDL_HWSURFACE|SDL_ASYNCBLIT) ) {
		SDL_VideoDevice *video = current_video;
		SDL_VideoDevice *this  = current_video;
		if ( video->LockHWSurface(this, surface) < 0 ) {
			return(-1);
		}
	}

	/* calculate the worst case size for the compressed surface */
	switch(bpp) {
	case 1:
	    /* worst case is alternating opaque and transparent pixels,
	       starting with an opaque pixel */
	    maxsize = surface->h * 3 * (surface->w / 2 + 1) + 2;
	    break;
	case 2:
	case 3:
	    /* worst case is solid runs, at most 255 pixels wide */
	    maxsize = surface->h * (2 * (surface->w / 255 + 1)
				    + surface->w * bpp) + 2;
	    break;
	case 4:
	    /* worst case is solid runs, at most 65535 pixels wide */
	    maxsize = surface->h * (4 * (surface->w / 65535 + 1)
				    + surface->w * 4) + 4;
	    break;
	}

	rlebuf = malloc(maxsize);
	if ( rlebuf == NULL ) {
		SDL_OutOfMemory();
		return(-1);
	}

	/* Set up the conversion */
	srcbuf = (Uint8 *)surface->pixels+surface->offset;
	curbuf = srcbuf;
	trim = surface->pitch - surface->w*bpp;
	maxn = bpp == 4 ? 65535 : 255;
	skip = run = 0;
	dst = rlebuf;

#define ADD_COUNT(n)						\
        do {							\
            if(bpp == 4) {					\
	        *(Uint16 *)dst = n;				\
	        dst += 2;					\
	    } else {						\
		*dst++ = n;					\
	    }							\
	} while(0)

#define ADD_SEGMENT()					\
	do {						\
	    while(blanks) {				\
		int ww = surface->w;			\
		while(ww) {				\
		    int n = MIN(maxn, ww);		\
		    ADD_COUNT(n);			\
		    ADD_COUNT(0);			\
		    ww -= n;				\
		}					\
		blanks--;				\
	    }						\
	    while(skip > maxn) {			\
		ADD_COUNT(maxn);			\
		ADD_COUNT(0);				\
		skip -= maxn;				\
	    }						\
	    {						\
		int len = MIN(run, maxn);		\
		ADD_COUNT(skip);			\
		ADD_COUNT(len);				\
		memcpy(dst, srcbuf, len * bpp);		\
		srcbuf += len * bpp;			\
		dst += len * bpp;			\
		run -= len;				\
	    }						\
            skip = 0;					\
	    while (run) {                               \
		int len = MIN(run, maxn);		\
		ADD_COUNT(0);				\
		ADD_COUNT(len);				\
		memcpy(dst, srcbuf, len * bpp);		\
		srcbuf += len * bpp;			\
		dst += len * bpp;			\
		run -= len;				\
	    }						\
	} while(0)

	blanks = 0;
	for(y = 0; y < surface->h; y++) {
	    blankline = 1;
	    skip = run = 0;
	    for(x = 0; x < surface->w; x++) {
		if(Transparent(curbuf, surface->format)) {
		    if(run)
			ADD_SEGMENT();
		    skip++;
		} else {
		    if(!run)
			srcbuf = curbuf; /* start of opaque pixel run */
		    run++;
		    blankline = 0;
		}
		curbuf += bpp;
	    }
	    if(blankline)
		blanks++;
	    else
		ADD_SEGMENT();
	    curbuf += trim;
	}
	ADD_COUNT(0);
	ADD_COUNT(0);

#undef ADD_SEGMENT
#undef ADD_COUNT

	/* Unlock the surface if it's in hardware */
	if ( surface->flags & (SDL_HWSURFACE|SDL_ASYNCBLIT) ) {
		SDL_VideoDevice *video = current_video;
		SDL_VideoDevice *this  = current_video;
		video->UnlockHWSurface(this, surface);
	}

	/* Now that we have it encoded, release the original pixels */
	free( surface->pixels );
	surface->pixels = NULL;

	/* realloc the buffer to release unused memory */
	{
	    /* If realloc returns NULL, the original block is left intact */
	    Uint8 *p = realloc(rlebuf, dst - rlebuf);
	    if(!p)
		p = rlebuf;
	    surface->map->sw_data->aux_data = p;
	}

	/* The surface is now accelerated */
	surface->flags |= SDL_RLEACCEL;

	return(0);
}

void SDL_UnRLESurface(SDL_Surface *surface, int recode)
{
	if ( (surface->flags & SDL_RLEACCEL) == SDL_RLEACCEL ) {
		surface->flags &= ~SDL_RLEACCEL;

		if(recode) {
		        SDL_Rect full;
		        /* re-create the original surface */
		        surface->pixels = malloc(surface->h * surface->pitch);

			/* fill it with the background colour */
			SDL_FillRect(surface, NULL, surface->format->colorkey);

			/* now render the encoded surface */
			full.x = full.y = 0;
			full.w = surface->w;
			full.h = surface->h;
			SDL_RLEBlit(surface, &full, surface, &full);
		}

		if ( surface->map && surface->map->sw_data->aux_data ) {
			free(surface->map->sw_data->aux_data);
			surface->map->sw_data->aux_data = NULL;
		}
	}
}

