#pragma once

char*  sdl_getenv(const char* name);
int    sdl_putenv(const char* cmdLine);

#define getenv(x) sdl_getenv(x)
#define putenv(x) sdl_putenv(x)