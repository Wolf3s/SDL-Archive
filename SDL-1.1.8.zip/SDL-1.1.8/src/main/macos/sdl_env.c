#include "sdl_env.h"
#include <string.h>
#include <stdlib.h>

static char** sdl_env = 0; /* NULL terminated list of env variables */

char *sdl_getenv(const char* name) {
   
  char **ptr = sdl_env;
  int    len = strlen (name);
  
  if (ptr == NULL)
    return NULL;
    
  while (*ptr != NULL) {
  
    if (strncmp (*ptr, name, len) == 0) {
      char *p = strchr (*ptr, '=');
      if ( (p - *ptr) == len)  
        return p+1;
    }
    ptr++;
  }
  
  return NULL;
}

int sdl_putenv(const char* name) {

  char   *p;
  char **ptr;
  int    size;
  
  p = strchr (name, '=');
      
  if (p == NULL)
    return -1;
  
  size = p - name;  
  ptr  = sdl_env;
   
  if (ptr != NULL)
    /* search for env, update it if found */
    while (*ptr != NULL) {
                    
       if (strncmp (*ptr, name, size) == 0) {
         /* check that sizes match too */
         p = strchr (*ptr, '=');
         if ( (p - *ptr) == size)                 
           if (strcmp ( (*ptr + size + 1), (name + size + 1) ) == 0)
             return 0;   
           else {
             free (*ptr);
             *ptr = (char*)  malloc  (strlen(name) + 1);
             if (*ptr == NULL)
               return -1;
             
             strcpy (*ptr, name);
             return 0;
           }
       }
      ptr++;
    }

  size = ptr - sdl_env + 1;
  
  sdl_env = (char**) realloc (sdl_env, size+1);
  if (sdl_env == NULL)
    return -1;
    
  sdl_env[size-1] = (char*)  malloc  (strlen(name) + 1);
  if (sdl_env[size-1] == NULL)
    return -1;
  
  strcpy (sdl_env[size-1], name);
  sdl_env[size] = NULL;
  
  return 0;
}
