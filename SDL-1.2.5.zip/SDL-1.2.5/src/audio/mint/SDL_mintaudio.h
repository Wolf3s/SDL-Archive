/*
 * MiNT audio driver
 * 
 * Patrice Mandin
 */

#ifndef _SDL_mintaudio_h
#define _SDL_mintaudio_h

#include "SDL_sysaudio.h"

/* Hidden "this" pointer for the audio functions */
#define _THIS	SDL_AudioDevice *this

#endif /* _SDL_mintaudio_h */
