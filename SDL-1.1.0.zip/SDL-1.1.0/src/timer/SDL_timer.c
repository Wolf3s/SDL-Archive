/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    5635-34 Springhouse Dr.
    Pleasanton, CA 94588 (USA)
    slouken@devolution.com
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_timer.c,v 1.1.2.3 2000/01/17 07:39:17 hercules Exp $";
#endif

#include <stdio.h>			/* For the definition of NULL */

#include "SDL_error.h"
#include "SDL_timer.h"
#include "SDL_timer_c.h"
#include "SDL_systimer.h"

int SDL_timer_started = 0;
int SDL_timer_running = 0;

/* Data to handle a single periodic alarm */
Uint32 SDL_alarm_interval = 0;
SDL_TimerCallback SDL_alarm_callback;

/* Data used for a thread-based timer */
static int SDL_timer_threaded = 0;
static Uint32 last_alarm;


/* Set whether or not the timer should use a thread.
   This should be called while the timer subsystem is running.
*/
int SDL_SetTimerThreaded(int value)
{
	int retval;

	if ( SDL_timer_started ) {
		SDL_SetError("Timer already initialized");
		retval = -1;
	} else {
		retval = 0;
		SDL_timer_threaded = value;
	}
	return retval;
}

int SDL_TimerInit(void)
{
	int retval;

	SDL_timer_running = 0;
	SDL_SetTimer(0, NULL);
	if ( SDL_timer_threaded ) {
		retval = 0;
	} else {
		retval = SDL_SYS_TimerInit();
	}
	SDL_timer_started = 1;
	return(retval);
}

void SDL_TimerQuit(void)
{
	SDL_SetTimer(0, NULL);
	if ( SDL_timer_threaded < 2 ) {
		SDL_SYS_TimerQuit();
	}
	SDL_timer_started = 0;
}

/* This function is called from the SDL event thread if it is available */
void SDL_ThreadedTimerCheck(void)
{
	Uint32 now, ms;

	now = SDL_GetTicks();
	/* If we are within SDL_TIMESLICE ms of target time, execute! */
	ms = (SDL_alarm_interval-SDL_TIMESLICE);
	if (  (last_alarm < now) && ((now - last_alarm) > ms) ) {
		if ( (now - last_alarm) < SDL_alarm_interval ) {
			last_alarm = last_alarm+SDL_alarm_interval;
		} else {
			last_alarm = now;
		}
		ms = (*SDL_alarm_callback)(SDL_alarm_interval);
		if ( ms != SDL_alarm_interval ) {
			if ( ms ) {
				SDL_alarm_interval = ROUND_RESOLUTION(ms);
			} else {
				SDL_SetTimer(0, NULL);
			}
		}
	}
}

int SDL_SetTimer (Uint32 ms, SDL_TimerCallback callback)
{
	int retval;

	retval = 0;
	if ( SDL_timer_running ) {	/* Stop any currently running timer */
		SDL_timer_running = 0;
		if ( SDL_timer_threaded ) {
			last_alarm = 0;
		} else {
			SDL_SYS_StopTimer();
		}
	}
	ms = ROUND_RESOLUTION(ms);
	SDL_alarm_interval = ms;
	SDL_alarm_callback = callback;
	if ( SDL_alarm_interval ) { /* Start a new timer, if desired */
		SDL_timer_running = 1;
		if ( SDL_timer_threaded ) {
			last_alarm = SDL_GetTicks();
		} else {
			retval = SDL_SYS_StartTimer();
		}
	}
	return retval;
}
