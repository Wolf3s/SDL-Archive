/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@devolution.com
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_sysjoystick.c,v 1.1.2.15 2000/03/30 21:47:55 hercules Exp $";
#endif

/* This is the system specific header for the SDL joystick API */

#include <stdio.h>		/* For the definition of NULL */
#include <stdlib.h>		/* For getenv() prototype */
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <linux/joystick.h>

#include "SDL_error.h"
#include "SDL_joystick.h"
#include "SDL_sysjoystick.h"
#include "SDL_joystick_c.h"

/* Define this if you want to map axes to hats and trackballs */
#define FANCY_HATS_AND_BALLS

#ifdef FANCY_HATS_AND_BALLS
/* Special joystick configurations:
	'JoystickName' Naxes Nhats Nballs
 */
static const char *special_joysticks[] = {
	"'MadCatz Panther XL' 3 2 1", /* We don't handle a rudder (axis 8) */
	"'SideWinder Precision Pro' 4 1 0",
	"'WingMan Interceptor' 3 3 0",
	/* WingMan Extreme Analog - not recognized by default
	"'Analog 3-axis 4-button joystick' 2 1",
	*/
	"'WingMan Extreme Digital 3D' 4 1 0",
	NULL
};
#endif

/* The base path of the joystick devices */
#define JOYDEV_PATTERN	"/dev/js%d"

/* The maximum number of joysticks we'll detect */
#define MAX_JOYSTICKS	16	

/* A list of available joysticks */
static char *SDL_joylist[MAX_JOYSTICKS];

/* The private structure used to keep track of a joystick */
struct joystick_hwdata {
	int fd;
	/* The current linux joystick driver maps hats to two axes */
	int analog_hat;		/* Well, except for analog hats */
	struct hwdata_hat {
		int axis[2];
	} *hats;
	/* The current linux joystick driver maps balls to two axes */
	struct hwdata_ball {
		int axis[2];
	} *balls;
};

/* Function to scan the system for joysticks */
int SDL_SYS_JoystickInit(void)
{
	int numjoysticks;
	int i, done;
	int fd;
	char path[128];

	numjoysticks = 0;
	done = 0;
	for ( i=0; (i < MAX_JOYSTICKS) && !done; ++i ) {
		sprintf(path, JOYDEV_PATTERN, i);
		if ( access(path, F_OK) == 0 ) {
			fd = open(path, O_RDONLY, 0);
			if ( fd >= 0 ) {
				close(fd);
			}
			if ( fd >= 0 ) {
				SDL_joylist[numjoysticks] = strdup(path);
				if ( SDL_joylist[numjoysticks] ) {
					++numjoysticks;
				}
			}
		} else {
			done = 1;
		}
	}
	return(numjoysticks);
}

/* Function to get the device-dependent name of a joystick */
const char *SDL_SYS_JoystickName(int index)
{
	int fd;
	static char namebuf[128];
	char *name;

	name = NULL;
	fd = open(SDL_joylist[index], O_RDONLY, 0);
	if ( fd >= 0 ) {
		if ( ioctl(fd, JSIOCGNAME(sizeof(namebuf)), namebuf) <= 0 ) {
			name = SDL_joylist[index];
		} else {
			name = namebuf;
		}
		close(fd);
	}
	return name;
}

#ifdef FANCY_HATS_AND_BALLS

static int allocate_hatdata(SDL_Joystick *joystick)
{
	int i;

	joystick->hwdata->hats = (struct hwdata_hat *)malloc(
		joystick->nhats * sizeof(struct hwdata_hat));
	if ( joystick->hwdata->hats == NULL ) {
		return(-1);
	}
	for ( i=0; i<joystick->nhats; ++i ) {
		joystick->hwdata->hats[i].axis[0] = 1;
		joystick->hwdata->hats[i].axis[1] = 1;
	}
	return(0);
}

static int allocate_balldata(SDL_Joystick *joystick)
{
	int i;

	joystick->hwdata->balls = (struct hwdata_ball *)malloc(
		joystick->nballs * sizeof(struct hwdata_ball));
	if ( joystick->hwdata->balls == NULL ) {
		return(-1);
	}
	for ( i=0; i<joystick->nballs; ++i ) {
		joystick->hwdata->balls[i].axis[0] = 0;
		joystick->hwdata->balls[i].axis[1] = 0;
	}
	return(0);
}

static SDL_bool ConfigJoystick(SDL_Joystick *joystick,
			const char *name, const char *config)
{
	char cfg_name[128];
	SDL_bool handled;

	if ( config == NULL ) {
		return(SDL_FALSE);
	}
	strcpy(cfg_name, "");
	if ( *config == '\'' ) {
		sscanf(config, "'%[^']s'", cfg_name);
		config += strlen(cfg_name)+2;
	} else {
		sscanf(config, "%s", cfg_name);
		config += strlen(cfg_name);
	}
	handled = SDL_FALSE;
	if ( strcmp(cfg_name, name) == 0 ) {
		/* Get the number of axes, hats and balls for this joystick */
		int joystick_axes = joystick->naxes;
		sscanf(config, "%d %d %d", 
			&joystick->naxes, &joystick->nhats, &joystick->nballs);

		/* Allocate the extra data for mapping them */
		if ( joystick->nhats > 0 ) {
			/* HACK: Analog hats map to only one axis */
			if (joystick_axes == (joystick->naxes+joystick->nhats)){
				joystick->hwdata->analog_hat = 1;
			} else {
				if ( allocate_hatdata(joystick) < 0 ) {
					joystick->nhats = 0;
				}
				joystick->hwdata->analog_hat = 0;
			}
		}
		if ( joystick->nballs > 0 ) {
			if ( allocate_balldata(joystick) < 0 ) {
				joystick->nballs = 0;
			}
		}
		handled = SDL_TRUE;
	}
	return(handled);
}

#endif /* FANCY_HATS_AND_BALLS */

/* Function to open a joystick for use.
   The joystick to open is specified by the index field of the joystick.
   This should fill the nbuttons and naxes fields of the joystick structure.
   It returns 0, or -1 if there is an error.
 */
int SDL_SYS_JoystickOpen(SDL_Joystick *joystick)
{
#ifdef FANCY_HATS_AND_BALLS
	const char *name;
	int i;
#endif
	int fd;
	unsigned char n;

	/* Open the joystick and set the joystick file descriptor */
	fd = open(SDL_joylist[joystick->index], O_RDONLY, 0);
	if ( fd < 0 ) {
		SDL_SetError("Unable to open %s\n",
		             SDL_joylist[joystick->index]);
		return(-1);
	}
	joystick->hwdata = (struct joystick_hwdata *)
	                   malloc(sizeof(*joystick->hwdata));
	if ( joystick->hwdata == NULL ) {
		SDL_OutOfMemory();
		close(fd);
		return(-1);
	}
	memset(joystick->hwdata, 0, sizeof(*joystick->hwdata));
	joystick->hwdata->fd = fd;

	/* Set the joystick to non-blocking read mode */
	fcntl(fd, F_SETFL, O_NONBLOCK);

	/* Get the number of buttons and axes on the joystick */
	if ( ioctl(fd, JSIOCGAXES, &n) < 0 ) {
		joystick->naxes = 2;
	} else {
		joystick->naxes = n;
	}
	if ( ioctl(fd, JSIOCGBUTTONS, &n) < 0 ) {
		joystick->nbuttons = 2;
	} else {
		joystick->nbuttons = n;
	}

#ifdef FANCY_HATS_AND_BALLS
	/* Check for special joystick support */
	name = SDL_SYS_JoystickName(joystick->index);
	for ( i=0; special_joysticks[i]; ++i ) {
		if ( ConfigJoystick(joystick, name,special_joysticks[i]) ) {
			break;
		}
	}
	if ( special_joysticks[i] == NULL ) {
		ConfigJoystick(joystick, name, getenv("SDL_LINUX_JOYSTICK"));
	}
#endif /* FANCY_HATS_AND_BALLS */

	return(0);
}

static inline
void HandleHat(SDL_Joystick *stick, Uint8 hat, int axis, int value)
{
	struct hwdata_hat *the_hat;
	const Uint8 position_map[3][3] = {
				{ 8, 1, 2 },
				{ 7, 0, 3 },
				{ 6, 5, 4 }
	};

	the_hat = &stick->hwdata->hats[hat];
	if ( value < 0 ) {
		value = 0;
	} else
	if ( value == 0 ) {
		value = 1;
	} else
	if ( value > 0 ) {
		value = 2;
	}
	if ( value != the_hat->axis[axis] ) {
		the_hat->axis[axis] = value;
		SDL_PrivateJoystickHat(stick, hat,
			position_map[the_hat->axis[1]][the_hat->axis[0]]);
	}
}

/* This was necessary for the Wingman Extreme Analog joystick */
static inline
void HandleAnalogHat(SDL_Joystick *stick, Uint8 hat, int value)
{
	const Uint8 position_map[] = { 1, 3, 5, 7, 0 };

	SDL_PrivateJoystickHat(stick, hat, position_map[(value/16000)+2]);
}

static inline
void HandleBall(SDL_Joystick *stick, Uint8 ball, int axis, int value)
{
	stick->hwdata->balls[ball].axis[axis] += value;
}

/* Function to update the state of a joystick - called as a device poll.
 * This function shouldn't update the joystick structure directly,
 * but instead should call SDL_PrivateJoystick*() to deliver events
 * and update joystick device state.
 */
void SDL_SYS_JoystickUpdate(SDL_Joystick *joystick)
{
	struct js_event events[32];
	int i, len;
	Uint8 other_axis;

	while ((len=read(joystick->hwdata->fd, events, (sizeof events))) > 0) {
		len /= sizeof(events[0]);
		for ( i=0; i<len; ++i ) {
			switch (events[i].type & ~JS_EVENT_INIT) {
			    case JS_EVENT_AXIS:
				if ( events[i].number < joystick->naxes ) {
					SDL_PrivateJoystickAxis(joystick,
				           events[i].number, events[i].value);
					break;
				}
				events[i].number -= joystick->naxes;
				if ( joystick->hwdata->analog_hat ) {
					other_axis = events[i].number;
					if ( other_axis < joystick->nhats ) {
						HandleAnalogHat(joystick, other_axis,
							events[i].value);
						break;
					}
				} else {
					other_axis = (events[i].number / 2);
					if ( other_axis < joystick->nhats ) {
						HandleHat(joystick, other_axis,
							events[i].number%2,
							events[i].value);
						break;
					}
				}
				events[i].number -= joystick->nhats*2;
				other_axis = (events[i].number / 2);
				if ( other_axis < joystick->nballs ) {
					HandleBall(joystick, other_axis,
						events[i].number%2,
						events[i].value);
					break;
				}
				break;
			    case JS_EVENT_BUTTON:
				SDL_PrivateJoystickButton(joystick,
				           events[i].number, events[i].value);
				break;
			    default:
				/* ?? */
				break;
			}
		}
	}
	for ( i=0; i<joystick->nballs; ++i ) {
		int xrel, yrel;

		xrel = joystick->hwdata->balls[i].axis[0];
		yrel = joystick->hwdata->balls[i].axis[1];
		if ( xrel || yrel ) {
			joystick->hwdata->balls[i].axis[0] = 0;
			joystick->hwdata->balls[i].axis[1] = 0;
			SDL_PrivateJoystickBall(joystick, (Uint8)i, xrel, yrel);
		}
	}
}

/* Function to close a joystick after use */
void SDL_SYS_JoystickClose(SDL_Joystick *joystick)
{
	if ( joystick->hwdata ) {
		close(joystick->hwdata->fd);
		if ( joystick->hwdata->hats ) {
			free(joystick->hwdata->hats);
		}
		if ( joystick->hwdata->balls ) {
			free(joystick->hwdata->balls);
		}
		free(joystick->hwdata);
		joystick->hwdata = NULL;
	}
}

/* Function to perform any system-specific joystick related cleanup */
void SDL_SYS_JoystickQuit(void)
{
	int i;

	for ( i=0; SDL_joylist[i]; ++i ) {
		free(SDL_joylist[i]);
	}
	SDL_joylist[0] = NULL;
}

