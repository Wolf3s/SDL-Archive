/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@devolution.com
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_romvideo.c,v 1.3.2.7 2000/03/16 15:20:39 hercules Exp $";
#endif

#include <stdio.h>
#include <stdlib.h>

#include <LowMem.h>
#include <Gestalt.h>
#include <Devices.h>
#include <DiskInit.h>
#include <QDOffscreen.h>

#include "SDL_video.h"
#include "SDL_error.h"
#include "SDL_syswm.h"
#include "SDL_sysvideo.h"
#include "SDL_romvideo.h"
#include "SDL_romwm_c.h"
#include "SDL_rommouse_c.h"
#include "SDL_romevents_c.h"

/* Initialization/Query functions */
static int Mac_VideoInit(_THIS, SDL_PixelFormat *vformat);
static SDL_Rect **Mac_ListModes(_THIS, SDL_PixelFormat *format, Uint32 flags);
static SDL_Surface *Mac_SetVideoMode(_THIS, SDL_Surface *current, int width, int height, int bpp, Uint32 flags);
static int Mac_SetColors(_THIS, int firstcolor, int ncolors);
static void Mac_VideoQuit(_THIS);

/* Hardware surface functions */
static int Mac_AllocHWSurface(_THIS, SDL_Surface *surface);
static int Mac_LockHWSurface(_THIS, SDL_Surface *surface);
static void Mac_UnlockHWSurface(_THIS, SDL_Surface *surface);
static void Mac_FreeHWSurface(_THIS, SDL_Surface *surface);

/* OpenGL functions */
static int Mac_GL_Init(_THIS);
#ifdef HAVE_OPENGL
static int Mac_GL_MakeCurrent(_THIS);
static void Mac_GL_SwapBuffers(_THIS);
#endif
static void Mac_GL_Quit(_THIS);

/* Saved state for the menu bar */
static RgnHandle	gSaveGrayRgn = nil;
static short		gSaveMenuBar = 0;
static Boolean		gSaveCSVis = true;

#if powerc
	/* Mixed mode glue to activate the 68K emulator and twiddle a register */
	#define ONEWORDSTUB(p1) \
			{ 0x41FA, 0x0010, 0x209F, (p1), 0x41FA, \
			  0x0008, 0x2F10, 0x4E75, 0x0000, 0x0000, 0x0000 }

	#define TWOWORDSTUB(p1,p2) \
			{ 0x41FA, 0x0012, 0x209F, (p1), (p2), 0x41FA, \
			  0x0008, 0x2F10, 0x4E75, 0x0000, 0x0000, 0x0000 }

	#define THREEWORDSTUB(p1,p2,p3) \
			{ 0x41FA, 0x0014, 0x209F, (p1), (p2), (p3), 0x41FA, \
			  0x0008, 0x2F10, 0x4E75, 0x0000, 0x0000, 0x0000 }

	/* ControlStrip inline glue for PowerPC */
	static pascal Boolean SBIsControlStripVisible(void) {
		static short procData[] = TWOWORDSTUB(0x7000, 0xAAF2);
		ProcInfoType procInfo = kD0DispatchedPascalStackBased
				| RESULT_SIZE(SIZE_CODE(sizeof(Boolean)))
            	| DISPATCHED_STACK_ROUTINE_SELECTOR_SIZE(kFourByteCode);
            				
		return((Boolean) 
				CallUniversalProc((UniversalProcPtr) procData, procInfo, 0x00));
		}

	static pascal void SBShowHideControlStrip(Boolean showIt) {
		static short procData[] = THREEWORDSTUB(0x303C, 0x0101, 0xAAF2);
		ProcInfoType procInfo = kD0DispatchedPascalStackBased
				| DISPATCHED_STACK_ROUTINE_SELECTOR_SIZE(kFourByteCode)
				| DISPATCHED_STACK_ROUTINE_PARAMETER(1, SIZE_CODE(sizeof(Boolean)));
				
		CallUniversalProc((UniversalProcPtr) procData, procInfo, 0x01, showIt);
		}
#endif /* powerc */

/* Macintosh toolbox driver bootstrap functions */

static int Mac_Available(void)
{
	return(1);
}

static void Mac_DeleteDevice(SDL_VideoDevice *device)
{
	free(device->hidden);
	free(device);
}

static SDL_VideoDevice *Mac_CreateDevice(int devindex)
{
	SDL_VideoDevice *device;

	/* Initialize all variables that we clean on shutdown */
	device = (SDL_VideoDevice *)malloc(sizeof(SDL_VideoDevice));
	if ( device ) {
		memset(device, 0, (sizeof *device));
		device->hidden = (struct SDL_PrivateVideoData *)
				malloc((sizeof *device->hidden));
	}
	if ( (device == NULL) || (device->hidden == NULL) ) {
		SDL_OutOfMemory();
		if ( device ) {
			free(device);
		}
		return(0);
	}
	memset(device->hidden, 0, (sizeof *device->hidden));

	/* Set the function pointers */
	device->VideoInit = Mac_VideoInit;
	device->ListModes = Mac_ListModes;
	device->SetVideoMode = Mac_SetVideoMode;
	device->SetColors = Mac_SetColors;
	device->UpdateRects = NULL;
	device->VideoQuit = Mac_VideoQuit;
	device->AllocHWSurface = Mac_AllocHWSurface;
	device->CheckHWBlit = NULL;
	device->FillHWRect = NULL;
	device->SetHWColorKey = NULL;
	device->SetHWAlpha = NULL;
	device->LockHWSurface = Mac_LockHWSurface;
	device->UnlockHWSurface = Mac_UnlockHWSurface;
	device->FlipHWSurface = NULL;
	device->FreeHWSurface = Mac_FreeHWSurface;
#ifdef HAVE_OPENGL
	device->GL_MakeCurrent = Mac_GL_MakeCurrent;
	device->GL_SwapBuffers = Mac_GL_SwapBuffers;
#endif
	device->SetIcon = NULL;
	device->SetCaption = Mac_SetCaption;
	device->GetWMInfo = NULL;
	device->FreeWMCursor = Mac_FreeWMCursor;
	device->CreateWMCursor = Mac_CreateWMCursor;
	device->ShowWMCursor = Mac_ShowWMCursor;
	device->WarpWMCursor = Mac_WarpWMCursor;
	device->InitOSKeymap = Mac_InitOSKeymap;
	device->PumpEvents = Mac_PumpEvents;

	device->free = Mac_DeleteDevice;

	return device;
}

VideoBootStrap TOOLBOX_bootstrap = {
	"toolbox", Mac_Available, Mac_CreateDevice
};


static int Mac_VideoInit(_THIS, SDL_PixelFormat *vformat)
{
	long info;
	
	/* Check out some things about the system */
	Gestalt(gestaltQuickdrawVersion, &info);
	if ( info == gestaltOriginalQD ) {
		SDL_SetError("Color Quickdraw not available");
		return(-1);
	}

	/* Start Macintosh events */
	Mac_InitEvents(this);

	/* Get a handle to the main monitor */
	SDL_Display = GetMainDevice();

	/* Determine pixel format */
	vformat->BitsPerPixel = (**(**SDL_Display).gdPMap).pixelSize;
	switch (vformat->BitsPerPixel) {
		case 16:	/* 5-5-5 RGB */
			vformat->Rmask = 0x00007c00;
			vformat->Gmask = 0x000003e0;
			vformat->Bmask = 0x0000001f;
			break;
		default:
			break;
	}

	/* Create our palette */
	SDL_CTab = (CTabHandle)NewHandle(sizeof(ColorSpec)*256 + 8);
	if ( SDL_CTab == nil ) {
		SDL_OutOfMemory();
		return(-1);
	}
	(**SDL_CTab).ctSeed = GetCTSeed();
	(**SDL_CTab).ctFlags = 0;
	(**SDL_CTab).ctSize = 255;
	CTabChanged(SDL_CTab);
	SDL_CPal = NewPalette(256, SDL_CTab, pmExplicit+pmTolerant, 0);

	/* Get a list of available fullscreen modes */
	SDL_modelist = (SDL_Rect **)malloc((1+1)*sizeof(SDL_Rect *));
	if ( SDL_modelist ) {
		SDL_modelist[0] = (SDL_Rect *)malloc(sizeof(SDL_Rect));
		if ( SDL_modelist[0] ) {
			SDL_modelist[0]->x = 0;
			SDL_modelist[0]->y = 0;
			SDL_modelist[0]->w = (**SDL_Display).gdRect.right;
			SDL_modelist[0]->h = (**SDL_Display).gdRect.bottom;
		}
		SDL_modelist[1] = NULL;
	}

	/* Fill in some window manager capabilities */
	this->info.wm_available = 1;

	/* We're done! */
	return(0);
}

static SDL_Rect **Mac_ListModes(_THIS, SDL_PixelFormat *format, Uint32 flags)
{
	if ( this->screen->format->BitsPerPixel == format->BitsPerPixel ) {
		if ( (flags & SDL_FULLSCREEN) == SDL_FULLSCREEN ) {
			return(SDL_modelist);
		} else {
			return((SDL_Rect **)-1);
		}
	} else {
		return((SDL_Rect **)0);
	}
}

static void Mac_HideMenuBar(_THIS)
{
	RgnHandle		drawRgn = nil;
	RgnHandle		tempRgn = nil;
	RgnHandle		grayRgn = nil;
	WindowPtr		window = nil;
	GDHandle		gd = nil;
	GrafPtr			savePort;
	long			response;
	short			height;
	EventRecord		theEvent;

	height = GetMBarHeight();
	
	if ( height > 0 ) {
		tempRgn = NewRgn();
		drawRgn = NewRgn();
		gSaveGrayRgn = NewRgn();
		if ( ! tempRgn || ! drawRgn || ! gSaveGrayRgn ) {
			goto CLEANUP;
		}
		grayRgn = GetGrayRgn(); /* No need to check for this */
	
		GetPort(&savePort);

		/* Hide the control strip if it's present, and record its 
		   previous position into the dirty region for redrawing. 
		   This isn't necessary, but may help catch stray bits. */
		CopyRgn(grayRgn, tempRgn);
		if (!Gestalt(gestaltControlStripAttr, &response) && 
			(response & (1L << gestaltControlStripExists))) {
			gSaveCSVis = SBIsControlStripVisible();
			if (gSaveCSVis)
				SBShowHideControlStrip(false);
		}
		DiffRgn(grayRgn, tempRgn, drawRgn);

		/* Save the gray region once the control strip is hidden*/
		CopyRgn(grayRgn, gSaveGrayRgn);

		/* Change the menu height in lowmem */
		gSaveMenuBar = height;
		LMSetMBarHeight(0);
		
		/* Walk the monitor rectangles, and combine any pieces that
		   aren't in GrayRgn: menubar, round corners, fake floaters. */
		for(gd = GetDeviceList(); gd; gd = GetNextDevice(gd)) 
			{
			if (!TestDeviceAttribute(gd, screenDevice)) continue;
			if (!TestDeviceAttribute(gd, screenActive)) continue;

			RectRgn(tempRgn, &(*gd)->gdRect);	/* Get the whole screen */
			DiffRgn(tempRgn, grayRgn, tempRgn); /* Subtract out GrayRgn */
			UnionRgn(tempRgn, drawRgn, drawRgn);/* Combine all the bits */
			}
			
		/* Add the bits into the GrayRgn */
		UnionRgn(drawRgn, grayRgn, grayRgn);

		/* Modify the vis regions of exposed windows */
		window = (FrontWindow()) ? FrontWindow() : (WindowPtr) -1L;
		PaintBehind(window, drawRgn);
		CalcVisBehind(window, drawRgn);

		SetPort(savePort);
		
		/* Yield time so that floaters can catch up */
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		}

CLEANUP:

	if (tempRgn) DisposeRgn(tempRgn);
	if (drawRgn) DisposeRgn(drawRgn);
}
	
static void Mac_ShowMenuBar(_THIS)
{
	RgnHandle		drawRgn = nil;
	RgnHandle		menuRgn = nil;
	RgnHandle		tempRgn = nil;
	RgnHandle		grayRgn = nil;
	WindowPtr		window = nil;
	GrafPtr			wMgrPort;
	GrafPtr			savePort;
	Rect			menuRect;
	long			response;
	short			height;
	EventRecord		theEvent;
	RGBColor		saveRGB;
	RGBColor		blackRGB = { 0, 0, 0 };

	height = GetMBarHeight();
	
	if ((height <= 0) && (gSaveMenuBar > 0)) {
		drawRgn = NewRgn();
		menuRgn = NewRgn();
		tempRgn = NewRgn();
		if ( ! tempRgn || ! drawRgn || ! gSaveGrayRgn ) {
			goto CLEANUP;
		}
		grayRgn = GetGrayRgn(); /* No need to check for this */
	
		GetPort(&savePort);
		GetWMgrPort(&wMgrPort);

		/* Set the height properly */
		LMSetMBarHeight(gSaveMenuBar);

		/* Restore the old GrayRgn: rounded corners, etc, but not
		   the menubar -- subtract that out first! */
		if (gSaveGrayRgn)
			{
			menuRect = (*GetMainDevice())->gdRect;
			menuRect.bottom = menuRect.top + gSaveMenuBar;
			RectRgn(menuRgn, &menuRect);

			DiffRgn(grayRgn, gSaveGrayRgn, drawRgn); 	/* What do we inval? */
			DiffRgn(drawRgn, menuRgn, drawRgn);			/* Clip out the menu */
			
			/* Now redraw the corners and other bits black */
			SetPort(wMgrPort);
			GetClip(tempRgn);
			SetClip(drawRgn);
			GetForeColor(&saveRGB);
			RGBForeColor(&blackRGB);
			PaintRgn(drawRgn);
			RGBForeColor(&saveRGB);
			SetClip(tempRgn);
			SetPort(savePort);
			
			UnionRgn(drawRgn, menuRgn, drawRgn);		/* Put back the menu */

			/* Now actually restore the GrayRgn */
			CopyRgn(gSaveGrayRgn, grayRgn);
			DisposeRgn(gSaveGrayRgn);
			gSaveGrayRgn = nil;
			}

		/* Modify the vis regions of exposed windows and draw menubar */
		window = (FrontWindow()) ? FrontWindow() : (WindowPtr) -1L;
		PaintBehind(window, drawRgn);
		CalcVisBehind(window, drawRgn);
		DrawMenuBar();

		SetPort(savePort);
		gSaveMenuBar = 0;

		/* Now show the control strip if it's present */
		if (!Gestalt(gestaltControlStripAttr, &response) && 
				(response & (1L << gestaltControlStripExists)))
			{
			if (gSaveCSVis && !SBIsControlStripVisible())
				SBShowHideControlStrip(true);
			gSaveCSVis = true;
			}

		/* Yield time so that floaters can catch up */
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		EventAvail(0, &theEvent);
		}

CLEANUP:

	if (drawRgn) DisposeRgn(drawRgn);
	if (menuRgn) DisposeRgn(menuRgn);
	if (tempRgn) DisposeRgn(tempRgn);
}

/* Various screen update functions available */
static void Mac_WindowUpdate(_THIS, int numrects, SDL_Rect *rects);
static void Mac_DirectUpdate(_THIS, int numrects, SDL_Rect *rects);

static void Mac_UnsetVideoMode(_THIS, SDL_Surface *current)
{
	/* Free the current window, if any */
	if ( SDL_Window != nil ) {
		GWorldPtr memworld;
		
		/* Handle OpenGL support */
		Mac_GL_Quit(this);

		memworld = (GWorldPtr)GetWRefCon(SDL_Window);
		if ( memworld != nil ) {
			UnlockPixels(GetGWorldPixMap(memworld));
			DisposeGWorld(memworld);
		}
		CloseWindow(SDL_Window);
		if ( (current->flags & SDL_FULLSCREEN) == SDL_FULLSCREEN ) {
			Mac_ShowMenuBar(this);
		}
		SDL_Window = nil;
	}
	current->pixels = NULL;
	current->flags &= ~(SDL_HWSURFACE|SDL_FULLSCREEN);
}

static SDL_Surface *Mac_SetVideoMode(_THIS, SDL_Surface *current,
				int width, int height, int bpp, Uint32 flags)
{
	Rect wrect;

	/* Free any previous video mode */
	Mac_UnsetVideoMode(this, current);

	/* Create the Mac window and SDL video surface */
	current->flags = 0;		/* Clear flags */
	current->w = width;
	current->h = height;
	SetRect(&wrect, 0, 0, width, height);
	OffsetRect(&wrect,
		(SDL_modelist[0]->w-width)/2, (SDL_modelist[0]->h-height)/2);

	if ( (flags & SDL_FULLSCREEN) == SDL_FULLSCREEN ) {
		current->flags |= SDL_HWSURFACE|SDL_FULLSCREEN;
		SDL_Window = NewCWindow(nil, &wrect, "\p", true, plainDBox,
						(WindowPtr)-1, false, 0);
		current->pitch = (**(**SDL_Display).gdPMap).rowBytes & 0x3FFF;
		current->pixels = (**(**SDL_Display).gdPMap).baseAddr;
		Mac_HideMenuBar(this);
		this->UpdateRects = Mac_DirectUpdate;
	} else {
		GWorldPtr memworld;
		PixMapHandle pixmap;
		SDL_Window = NewCWindow(nil, &wrect, "\p", true, noGrowDocProc,
						(WindowPtr)-1, true, 0);
		SetPalette(SDL_Window, SDL_CPal, false);
		ActivatePalette(SDL_Window);
		if ( NewGWorld(&memworld, 0, &SDL_Window->portRect, SDL_CTab,
							nil, 0) != noErr ) {
			SDL_SetError("NewGWorld() failed");
			return(NULL);
		}
		SetWRefCon(SDL_Window, (long)memworld);
		pixmap = GetGWorldPixMap(memworld);
		LockPixels(pixmap);
		current->pitch = (**pixmap).rowBytes & 0x3FFF;
		current->pixels = GetPixBaseAddr(pixmap);
		this->UpdateRects = Mac_WindowUpdate;
	}
	SetPort(SDL_Window);
	SelectWindow(SDL_Window);

	/* Handle OpenGL support */
	if ( flags & SDL_OPENGL ) {
		if ( Mac_GL_Init(this) == 0 ) {
			current->flags |= SDL_OPENGL;
		} else {
			current = NULL;
		}
	}
	
	/* We're live! */
	return(current);
}

/* We don't actually allow hardware surfaces other than the main one */
static int Mac_AllocHWSurface(_THIS, SDL_Surface *surface)
{
	return(-1);
}
static void Mac_FreeHWSurface(_THIS, SDL_Surface *surface)
{
	return;
}
static int Mac_LockHWSurface(_THIS, SDL_Surface *surface)
{
	return(0);
}
static void Mac_UnlockHWSurface(_THIS, SDL_Surface *surface)
{
	return;
}

static void Mac_DirectUpdate(_THIS, int numrects, SDL_Rect *rects)
{
	/* The application is already updating the visible video memory */
	return;
}

static void Mac_WindowUpdate(_THIS, int numrects, SDL_Rect *rects)
{
	GWorldPtr memworld;
	WindowPtr saveport;
	int i;
	Rect update;
	
	/* Copy from the offscreen GWorld to the window port */
	GetPort(&saveport);
	SetPort(SDL_Window);
	memworld = (GWorldPtr)GetWRefCon(SDL_Window);
	for ( i=0; i<numrects; ++i ) {
		update.left = rects[i].x;
		update.right = rects[i].x+rects[i].w;
		update.top = rects[i].y;
		update.bottom = rects[i].y+rects[i].h;
		CopyBits(&((GrafPtr)memworld)->portBits, &SDL_Window->portBits,
						&update, &update, srcCopy, nil);
	}
	SetPort(saveport);
}

#ifdef HAVE_OPENGL

/* Make the current context active */
int Mac_GL_MakeCurrent(_THIS)
{
	int retval;

	retval = 0;
	if( ! aglSetCurrentContext(glContext) ) {
		SDL_SetError("Unable to make GL context current");
		retval = -1;
	}
	return(retval);
}

void Mac_GL_SwapBuffers(_THIS)
{
	aglSwapBuffers(glContext);
}

#endif /* HAVE_OPENGL */

static int Mac_SetColors(_THIS, int firstcolor, int ncolors)
{
	SDL_Palette *palette;
	CTabHandle cTab;
	int i;

	/* Get the colortable from the either the display or window */
	if ( (this->screen->flags & SDL_FULLSCREEN) == SDL_FULLSCREEN ) {
		cTab = (**(**SDL_Display).gdPMap).pmTable;
	} else {
		cTab = SDL_CTab;
	}

	/* Verify the range of colors */
	if ( (firstcolor+ncolors) > ((**cTab).ctSize+1) ) {
		return(0);
	}
	
	/* Set the screen palette and update the display */
	palette = this->screen->format->palette;
	for ( i=firstcolor; i<(firstcolor+ncolors); ++i ) {
		(**cTab).ctTable[i].value = i;
		(**cTab).ctTable[i].rgb.red =
			(palette->colors[i].r << 8) | palette->colors[i].r;
		(**cTab).ctTable[i].rgb.green =
			(palette->colors[i].g << 8) | palette->colors[i].g;
		(**cTab).ctTable[i].rgb.blue =
			(palette->colors[i].b << 8) | palette->colors[i].b;
	}
	if ( (this->screen->flags & SDL_FULLSCREEN) == SDL_FULLSCREEN ) {
		GDevice **odisplay;
		odisplay = GetGDevice();
		SetGDevice(SDL_Display);
		SetEntries(0, (**cTab).ctSize, (ColorSpec *)&(**cTab).ctTable);
		SetGDevice(odisplay);
	}
	return(1);
}

void Mac_VideoQuit(_THIS)
{
	int i;

	/* Free current video mode */
	Mac_UnsetVideoMode(this, this->screen);

	/* Free palette and restore original one */
	if ( SDL_CTab != nil ) {
		DisposeHandle((Handle)SDL_CTab);
		SDL_CTab = nil;
	}
	if ( SDL_CPal != nil ) {
		DisposePalette(SDL_CPal);
		SDL_CPal = nil;
	}
	RestoreDeviceClut(GetMainDevice());

	/* Free list of video modes */
	if ( SDL_modelist != NULL ) {
		for ( i=0; SDL_modelist[i]; ++i ) {
			free(SDL_modelist[i]);
		}
		free(SDL_modelist);
		SDL_modelist = NULL;
	}
}

/* krat: adding OpenGL support */
static int Mac_GL_Init(_THIS)
{
#ifdef HAVE_OPENGL
	int i;
	GLint attributes[] = {
		AGL_RGBA,
		AGL_RED_SIZE, 0,
		AGL_GREEN_SIZE, 0,
		AGL_BLUE_SIZE, 0,
		AGL_ALPHA_SIZE, 0,
		AGL_DEPTH_SIZE, 0,
		AGL_STENCIL_SIZE, 0,
		AGL_ACCUM_RED_SIZE, 0,
		AGL_ACCUM_GREEN_SIZE, 0,
		AGL_ACCUM_BLUE_SIZE, 0,
		AGL_ACCUM_ALPHA_SIZE, 0,
		AGL_DOUBLEBUFFER,	/* This must be second to last! */
		AGL_NONE
	};
	AGLPixelFormat format;
	GLboolean noerr;

	/* Fill in the attributes from our config */
	for ( i=0; attributes[i] != AGL_NONE; ++i ) {
		switch (attributes[i]) {
		    case AGL_RGBA:
			break;
		    case AGL_RED_SIZE:
			attributes[++i] = this->gl_config.red_size;
			break;
		    case AGL_GREEN_SIZE:
			attributes[++i] = this->gl_config.green_size;
			break;
		    case AGL_BLUE_SIZE:
			attributes[++i] = this->gl_config.blue_size;
			break;
		    case AGL_ALPHA_SIZE:
			attributes[++i] = this->gl_config.alpha_size;
			break;
		    case AGL_DEPTH_SIZE:
			attributes[++i] = this->gl_config.depth_size;
			break;
		    case AGL_STENCIL_SIZE:
			attributes[++i] = this->gl_config.stencil_size;
			break;
		    case AGL_ACCUM_RED_SIZE:
			attributes[++i] = this->gl_config.accum_red_size;
			break;
		    case AGL_ACCUM_GREEN_SIZE:
			attributes[++i] = this->gl_config.accum_green_size;
			break;
		    case AGL_ACCUM_BLUE_SIZE:
			attributes[++i] = this->gl_config.accum_blue_size;
			break;
		    case AGL_ACCUM_ALPHA_SIZE:
			attributes[++i] = this->gl_config.accum_alpha_size;
			break;
		    case AGL_DOUBLEBUFFER:
			if ( ! this->gl_config.double_buffer ) {
				attributes[i] = AGL_NONE;
			}
			break;
		    default:
			/* Uhh.... ? */;
			break;
		}
	}
	format = aglChoosePixelFormat(NULL, 0, attributes);
	if ( format == NULL ) {
		SDL_SetError("Couldn't match OpenGL desired format");
		return(-1);
	}

	glContext = aglCreateContext(format, NULL);
	if ( glContext == NULL ) {
		SDL_SetError("Couldn't create OpenGL context");
		return(-1);
	}
	aglDestroyPixelFormat(format);

	noerr = aglSetDrawable(glContext, (CGrafPort *)SDL_Window);
	if(!noerr) {
		SDL_SetError("Unable to bind GL context to window");
		return(-1);
	}
	return(0);
#else
	SDL_SetError("OpenGL support not configured");
	return(-1);
#endif
}

static void Mac_GL_Quit(_THIS)
{
#ifdef HAVE_OPENGL
	if ( glContext != NULL ) {
		aglSetCurrentContext(NULL);
		aglSetDrawable(glContext, NULL);
		aglDestroyContext(glContext);		
		glContext = NULL;
	}
#endif
}

