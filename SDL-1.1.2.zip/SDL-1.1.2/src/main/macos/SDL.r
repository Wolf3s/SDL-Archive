
#include "Dialogs.r"
#include "Menus.r"


resource 'DLOG' (1000) {
	{114, 64, 219, 428},
	dBoxProc,
	visible,
	noGoAway,
	0x0,
	1000,
	"Command Line",
	centerMainScreen
};

resource 'DITL' (1000) {
	{
		// The OK button
		{70, 288, 90, 346},
		Button {
			enabled,
			"OK"
		},
		// The Cancel button
		{70, 210, 90, 268},
		Button {
			enabled,
			"Cancel"
		},
		// The command line edit
		{40, 40, 56, 325},
		EditText {
			enabled,
			""
		},
		{70,20,88,126},
		CheckBox {
			enabled,
			"Output to file"
		},
		// A little explantation
		{16, 10, 32, 325},
		StaticText {
			enabled,
			"Command Line:"
		}
	}
};

resource 'DLOG' (1001) {
{114, 64, 219, 428},
	dBoxProc,
	visible,
	noGoAway,
	0x0,
	1001,
	"Error Window",
	centerMainScreen

};

resource 'DITL' (1001) {
	{
		// The OK button
		{70, 288, 90, 346},
		Button {
			enabled,
			"OK"
		},
		//where to stick the bad news
		{16,10,56,352},
		StaticText {
			enabled,
			""
		}
	}
};


resource 'MENU' (128, preload) {
	128,
	textMenuProc,
	0x7FFFFFFD,
	enabled,
	apple,
	{ "About SDL...", noIcon, noKey, noMark, plain,
	  "-", noIcon, noKey, noMark, plain
	}
};


//the following data structures are for resedit, so it knows the format
//of the CLne interface, which will allow the programer to edit the stored
//command line using a GUI instead of a Hex Editor
type 'TMPL'
{
	array dataTypes {
		pstring;
		longint;
	};
};


resource 'TMPL' (128, "CLne") 
{
	{
		"Command Line", 'PSTR',
		"Save To File", 'BOOL'
	}
};
